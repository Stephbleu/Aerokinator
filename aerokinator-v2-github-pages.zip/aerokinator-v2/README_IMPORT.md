# Importer la base de 3 741 modèles

Le workflow GitHub Actions `Importer la base aéronautique (2 000+ fiches)` télécharge la source CFR, convertit le CSV en fichiers JSON, contrôle le seuil de 2 000 fiches et l'unicité des identifiants, puis pousse les fichiers `data/` dans le dépôt.

Dans GitHub : **Actions** → **Importer la base aéronautique (2 000+ fiches)** → **Run workflow**.

La source annonce 3 741 modèles distincts. Les champs non présents dans la source ne sont pas inventés. Voir `SOURCES.md` pour l'attribution et les conditions de licence (CC BY-NC-SA, non-commercial).
