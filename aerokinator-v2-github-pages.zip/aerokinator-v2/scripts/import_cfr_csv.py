#!/usr/bin/env python3
"""Importe les 3 741 modèles du CFR Aircraft Engines Database dans Aérokinator.
Source amont : https://github.com/The-CFR-Project/AircraftEnginesDatabase
Licence amont : CC BY-NC-SA (voir SOURCES.md). Ne pas utiliser commercialement sans autorisation.
"""
import csv, json, re, sys, unicodedata
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'

def slug(s):
    s = unicodedata.normalize('NFKD', str(s or '')).encode('ascii', 'ignore').decode().lower()
    return re.sub(r'[^a-z0-9]+', '-', s).strip('-') or 'aircraft'

def val(row, key):
    x = (row.get(key) or '').strip()
    return x or None

def integer(x):
    try: return int(str(x).strip()) if x and str(x).strip().isdigit() else None
    except Exception: return None

def category(row):
    c = (val(row, 'aircraft_category') or '').lower()
    b = (val(row, 'body_type') or '').lower()
    if 'helicopter' in c or 'gyrocopter' in c or 'tiltrotor' in c or 'helicopter' in b: return 'helicopters'
    if 'seaplane' in c or 'amphibian' in c: return 'amphibious'
    if 'military' in b: return 'military'
    if 'glider' in c or 'sailplane' in c or 'glider' in b: return 'gliders'
    return 'civil'

def propulsion(x):
    return {'Jet':'Réacteur','Turboprop/Turboshaft':'Turbopropulseur / turbomoteur','Piston':'Piston','Electric':'Électrique'}.get(x, x)

def main(src):
    rows=[]; seen=set(); used_ids=set()
    with open(src, encoding='utf-8-sig', newline='') as f:
        for row in csv.DictReader(f):
            manufacturer=val(row,'manufacturer') or 'Constructeur inconnu'
            model=val(row,'model')
            if not model: continue
            key=(slug(manufacturer),slug(model))
            if key in seen: continue
            seen.add(key)
            cat=category(row)
            engine_count=integer(val(row,'engine_count'))
            engine_type=val(row,'engine_type')
            body=val(row,'body_type')
            aircraft_cat=val(row,'aircraft_category')
            code=val(row,'aircraft_type')
            desc=val(row,'description')
            source_urls=[]
            for field in ('engine_source','max_seats_source'):
                u=val(row,field)
                if u and u not in source_urls: source_urls.append(u)
            base_id='cfr-'+slug(manufacturer+'-'+model)
            ident=base_id; suffix=2
            while ident in used_ids:
                ident=f'{base_id}-{suffix}'; suffix+=1
            used_ids.add(ident)
            rec={
              'id': ident, 'familyId':ident,
              'name':f'{manufacturer} {model}', 'manufacturer':manufacturer, 'country':None,
              'category':cat, 'type': {'LandPlane':'Avion terrestre','SeaPlane':'Hydravion','Helicopter':'Hélicoptère','Gyrocopter':'Autogire','Tiltrotor':'Convertible / tiltrotor','Amphibian':'Avion amphibie'}.get(aircraft_cat, aircraft_cat or 'Aéronef'),
              'role': {'Military':'Militaire','Helicopter':'Hélicoptère','UAV':'Drone / aéronef sans pilote','Private':'Aviation générale','Regional':'Transport régional','Narrow':'Avion de ligne monocouloir','Wide':'Avion de ligne gros-porteur','Freighter':'Cargo','Utility':'Utilitaire'}.get(body, body),
              'status':'unknown','era':None,'firstFlight':None,'variantOf':None,'variant':None,
              'propulsion':propulsion(engine_type), 'engineType':engine_type, 'engineCount':engine_count,
              'performance':{'maxSpeed':None,'range':None,'ceiling':None},
              'capacity':{'crew':None,'seats':val(row,'max_seats')},
              'icaoCode':code,'icaoDescription':desc,'aircraftCategory':aircraft_cat,
              'engineManufacturer':val(row,'engine_manufacturer'),'engineModel':val(row,'engine_model'),
              'bodyType':body,'maxSeats':val(row,'max_seats'),
              'keywords':' '.join(x for x in [model,code,desc,aircraft_cat,body,engine_type,val(row,'engine_model')] if x),
              'image':{'provider':'wikimedia-commons','query':f'{manufacturer} {model} aircraft'},
              'sources':[{'url':u} for u in source_urls], 'dataQuality':'CFR-imported; technical fields as supplied; unknown fields intentionally blank'
            }
            rows.append(rec)

    # Preserve the hand-curated starter records when they are not already represented.
    existing_keys=set(seen)
    for filename in ('civil.json','military.json'):
        p=DATA/filename
        if not p.exists(): continue
        try: starter=json.loads(p.read_text(encoding='utf-8'))
        except Exception: starter=[]
        for rec in starter:
            k=(slug(rec.get('manufacturer')),slug(rec.get('name','').replace((rec.get('manufacturer') or '')+' ','',1)))
            if k not in existing_keys:
                if rec.get('id') in used_ids:
                    rec['id']=rec.get('id','starter')+'-seed'
                used_ids.add(rec.get('id'))
                rows.append(rec); existing_keys.add(k)

    grouped=defaultdict(list)
    index=[]
    for r in rows:
        grouped[r['category']].append(r)
        index.append({k:r.get(k) for k in ['id','familyId','name','manufacturer','country','category','type','role','status','era','propulsion','engineCount','firstFlight','keywords','icaoCode','bodyType','maxSeats']})
    DATA.mkdir(exist_ok=True)
    cats={}
    for cat, records in sorted(grouped.items()):
        (DATA/f'{cat}.json').write_text(json.dumps(records,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
        cats[cat]={'file':f'{cat}.json','count':len(records)}
    (DATA/'index.json').write_text(json.dumps(index,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    manifest={'schemaVersion':'1.1.0','datasetVersion':'CFR-3741-import','generatedAt':__import__('datetime').date.today().isoformat(),'recordCount':len(index),'sourceRecordCount':len(seen),'status':'imported-open-dataset-review-fields-as-supplied','categories':cats,'loading':'category-sharded-json; detail files fetched on demand','imageProvider':'Wikimedia Commons API','source':'The-CFR-Project/AircraftEnginesDatabase'}
    (DATA/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'source_records':len(seen),'total_records':len(index),'categories':{k:v['count'] for k,v in cats.items()}},ensure_ascii=False))
    if len(seen)<2000: raise SystemExit('ERREUR : moins de 2 000 modèles distincts dans la source')

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('Usage: python scripts/import_cfr_csv.py aircraft_engines.csv')
    main(sys.argv[1])
